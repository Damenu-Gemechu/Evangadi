function Child({ children }) {
	console.log(children);
	return <div>{children}</div>;
}
export default Child;
