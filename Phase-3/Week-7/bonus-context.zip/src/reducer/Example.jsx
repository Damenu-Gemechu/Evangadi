import Child from './Child';

function Example() {
	return (
		<div>
			<Child>
				<a href='/'>test</a>
				<h2>nigat</h2>
			</Child>
		</div>
	);
}
export default Example;
