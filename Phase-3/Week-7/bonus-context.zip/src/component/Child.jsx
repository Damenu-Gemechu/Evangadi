function Child({ data }) {
	return (
		<div>
			<h3>Child</h3>
			<h5> data from app ---- {data}</h5>
		</div>
	);
}
export default Child;
