import Child from './Child';

function Parent() {
	return (
		<div>
			<h2>Parent</h2>
			<hr />
			<Child />
		</div>
	);
}
export default Parent;
