import { useReducer } from 'react';
import Example from './reducer/Example';
function reducer(preState, action) {
	console.log(preState);
	if (action.type === 'INCREASE') {
		return { ...preState, num: preState.num + 1 };
	}
	if (action.type === 'DECREASE') {
		return { ...preState, num: preState.num - 1 };
	}
	return preState;
}

function App() {
	const [state, dispatch] = useReducer(reducer, {
		num: 0,
		product: ['iphone'],
	});

	return (
		<div>
			<button
				onClick={() => {
					dispatch({ type: 'INCREASE' });
				}}
			>
				INCREASE
			</button>
			<button
				onClick={() => {
					dispatch({ type: 'DECREASE' });
				}}
			>
				DECREASE
			</button>

			<h1>{state.num}</h1>
		</div>
	);
}
export default App;

// import GrandParent from './component-context/GrandParent';
// import { createContext, useContext } from 'react';

// export const DataProvider = createContext();

// export function useAppData() {
// 	return useContext(DataProvider);
// }

// function App() {
// 	return (
// 		<DataProvider.Provider value={{ test: 'june group-1' }}>
// 			<GrandParent />
// 		</DataProvider.Provider>
// 	);
// }

// export default App;
