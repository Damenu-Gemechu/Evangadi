import Child from './Child';
import { useAppData } from '../App';

function Parent() {
	const x = useAppData();
	console.log(x);
	return (
		<div>
			<h2>Parent</h2>
			<hr />
			<Child />
		</div>
	);
}
export default Parent;
