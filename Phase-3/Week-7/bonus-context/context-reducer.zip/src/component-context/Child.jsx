import { useContext } from 'react';
import { DataProvider } from '../App';

function Child() {
	const { test } = useContext(DataProvider);
	return (
		<div>
			<h3>Child</h3>
			<h5> data from app {test} </h5>
		</div>
	);
}
export default Child;
